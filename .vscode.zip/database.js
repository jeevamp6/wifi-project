const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const path = require('path');

// Database file path
const DB_PATH = path.join(__dirname, 'wifi_monitoring.db');

class Database {
  constructor() {
    this.db = null;
  }

  // Initialize database connection
  async init() {
    return new Promise((resolve, reject) => {
      this.db = new sqlite3.Database(DB_PATH, (err) => {
        if (err) {
          console.error('Error opening database:', err);
          reject(err);
        } else {
          console.log('Connected to SQLite database');
          this.createTables().then(resolve).catch(reject);
        }
      });
    });
  }

  // Create database tables
  async createTables() {
    return new Promise((resolve, reject) => {
      const queries = [
        // Users table
        `CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          fullname TEXT NOT NULL,
          email TEXT UNIQUE NOT NULL,
          username TEXT UNIQUE NOT NULL,
          role TEXT NOT NULL DEFAULT 'user',
          password TEXT NOT NULL,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          is_active BOOLEAN DEFAULT 1,
          last_login DATETIME
        )`,
        
        // Activity logs table
        `CREATE TABLE IF NOT EXISTS activity_logs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER,
          username TEXT,
          action TEXT NOT NULL,
          timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
          ip_address TEXT,
          FOREIGN KEY (user_id) REFERENCES users (id)
        )`,
        
        // Districts table
        `CREATE TABLE IF NOT EXISTS districts (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT UNIQUE NOT NULL,
          total_hotspots INTEGER DEFAULT 0,
          active_hotspots INTEGER DEFAULT 0,
          utilization INTEGER DEFAULT 0,
          status TEXT DEFAULT 'normal',
          last_ping DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        
        // System settings table
        `CREATE TABLE IF NOT EXISTS system_settings (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          setting_key TEXT UNIQUE NOT NULL,
          setting_value TEXT,
          description TEXT,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        
        // Wi-Fi metrics table (for historical data)
        `CREATE TABLE IF NOT EXISTS wifi_metrics (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          total_hotspots INTEGER,
          active_hotspots INTEGER,
          utilization INTEGER,
          critical_districts INTEGER,
          timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )`
      ];

      let completed = 0;
      queries.forEach(query => {
        this.db.run(query, (err) => {
          if (err) {
            console.error('Error creating table:', err);
            reject(err);
          } else {
            completed++;
            if (completed === queries.length) {
              this.seedInitialData().then(resolve).catch(reject);
            }
          }
        });
      });
    });
  }

  // Seed initial data
  async seedInitialData() {
    return new Promise((resolve, reject) => {
      // Create default admin user
      const hashedPassword = bcrypt.hashSync('admin123', 10);
      
      this.db.run(
        `INSERT OR IGNORE INTO users (fullname, email, username, role, password) VALUES (?, ?, ?, ?, ?)`,
        ['System Administrator', 'admin@wifi-monitor.com', 'admin', 'admin', hashedPassword],
        (err) => {
          if (err) {
            console.error('Error creating admin user:', err);
            reject(err);
          } else {
            // Initialize districts
            this.initializeDistricts().then(resolve).catch(reject);
          }
        }
      );
    });
  }

  // Initialize districts
  async initializeDistricts() {
    return new Promise((resolve, reject) => {
      const districts = [
        'North District', 'South District', 'East District', 'West District', 'Central District',
        'Northeast District', 'Northwest District', 'Southeast District', 'Southwest District', 'Metro District'
      ];

      let completed = 0;
      districts.forEach((name, index) => {
        const totalHotspots = Math.floor(Math.random() * 2000) + 500;
        const activeHotspots = Math.floor(Math.random() * 1500) + 300;
        const utilization = Math.floor(Math.random() * 40) + 40;
        const status = Math.random() > 0.7 ? 'critical' : Math.random() > 0.4 ? 'warning' : 'normal';

        this.db.run(
          `INSERT OR REPLACE INTO districts (id, name, total_hotspots, active_hotspots, utilization, status) VALUES (?, ?, ?, ?, ?, ?)`,
          [index + 1, name, totalHotspots, activeHotspots, utilization, status],
          (err) => {
            if (err) {
              console.error('Error inserting district:', err);
            } else {
              completed++;
              if (completed === districts.length) {
                // Initialize system settings
                this.initializeSettings().then(resolve).catch(reject);
              }
            }
          }
        );
      });
    });
  }

  // Initialize system settings
  async initializeSettings() {
    return new Promise((resolve, reject) => {
      const settings = [
        ['update_interval', '2', 'Data update interval in seconds'],
        ['critical_threshold', '80', 'Critical threshold percentage'],
        ['max_logs', '100', 'Maximum number of activity logs to keep']
      ];

      let completed = 0;
      settings.forEach(([key, value, description]) => {
        this.db.run(
          `INSERT OR IGNORE INTO system_settings (setting_key, setting_value, description) VALUES (?, ?, ?)`,
          [key, value, description],
          (err) => {
            if (err) {
              console.error('Error inserting setting:', err);
            } else {
              completed++;
              if (completed === settings.length) {
                resolve();
              }
            }
          }
        );
      });
    });
  }

  // User management methods
  async createUser(userData) {
    return new Promise((resolve, reject) => {
      const hashedPassword = bcrypt.hashSync(userData.password, 10);
      
      this.db.run(
        `INSERT INTO users (fullname, email, username, role, password) VALUES (?, ?, ?, ?, ?)`,
        [userData.fullname, userData.email, userData.username, userData.role, hashedPassword],
        function(err) {
          if (err) {
            reject(err);
          } else {
            resolve({ id: this.lastID, ...userData });
          }
        }
      );
    });
  }

  async authenticateUser(username, password) {
    return new Promise((resolve, reject) => {
      this.db.get(
        `SELECT * FROM users WHERE username = ? AND is_active = 1`,
        [username],
        (err, row) => {
          if (err) {
            reject(err);
          } else if (!row) {
            resolve(null);
          } else {
            const isValid = bcrypt.compareSync(password, row.password);
            if (isValid) {
              // Update last login
              this.db.run(
                `UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?`,
                [row.id]
              );
              resolve(row);
            } else {
              resolve(null);
            }
          }
        }
      );
    });
  }

  async getAllUsers() {
    return new Promise((resolve, reject) => {
      this.db.all(
        `SELECT id, fullname, email, username, role, created_at, is_active, last_login FROM users ORDER BY created_at DESC`,
        [],
        (err, rows) => {
          if (err) {
            reject(err);
          } else {
            resolve(rows);
          }
        }
      );
    });
  }

  async updateUser(userId, updates) {
    return new Promise((resolve, reject) => {
      const fields = Object.keys(updates).map(key => `${key} = ?`).join(', ');
      const values = Object.values(updates);
      
      this.db.run(
        `UPDATE users SET ${fields} WHERE id = ?`,
        [...values, userId],
        function(err) {
          if (err) {
            reject(err);
          } else {
            resolve({ changes: this.changes });
          }
        }
      );
    });
  }

  async deleteUser(userId) {
    return new Promise((resolve, reject) => {
      this.db.run(
        `DELETE FROM users WHERE id = ?`,
        [userId],
        function(err) {
          if (err) {
            reject(err);
          } else {
            resolve({ changes: this.changes });
          }
        }
      );
    });
  }

  // District management methods
  async getAllDistricts() {
    return new Promise((resolve, reject) => {
      this.db.all(
        `SELECT * FROM districts ORDER BY name`,
        [],
        (err, rows) => {
          if (err) {
            reject(err);
          } else {
            resolve(rows);
          }
        }
      );
    });
  }

  async updateDistrict(districtId, updates) {
    return new Promise((resolve, reject) => {
      const fields = Object.keys(updates).map(key => `${key} = ?`).join(', ');
      const values = Object.values(updates);
      
      this.db.run(
        `UPDATE districts SET ${fields}, last_ping = CURRENT_TIMESTAMP WHERE id = ?`,
        [...values, districtId],
        function(err) {
          if (err) {
            reject(err);
          } else {
            resolve({ changes: this.changes });
          }
        }
      );
    });
  }

  // Activity log methods
  async logActivity(userId, username, action, ipAddress = null) {
    return new Promise((resolve, reject) => {
      this.db.run(
        `INSERT INTO activity_logs (user_id, username, action, ip_address) VALUES (?, ?, ?, ?)`,
        [userId, username, action, ipAddress],
        function(err) {
          if (err) {
            reject(err);
          } else {
            resolve({ id: this.lastID });
          }
        }
      );
    });
  }

  async getActivityLogs(limit = 100) {
    return new Promise((resolve, reject) => {
      this.db.all(
        `SELECT * FROM activity_logs ORDER BY timestamp DESC LIMIT ?`,
        [limit],
        (err, rows) => {
          if (err) {
            reject(err);
          } else {
            resolve(rows);
          }
        }
      );
    });
  }

  async clearActivityLogs() {
    return new Promise((resolve, reject) => {
      this.db.run(
        `DELETE FROM activity_logs`,
        [],
        function(err) {
          if (err) {
            reject(err);
          } else {
            resolve({ changes: this.changes });
          }
        }
      );
    });
  }

  // System settings methods
  async getSetting(key) {
    return new Promise((resolve, reject) => {
      this.db.get(
        `SELECT setting_value FROM system_settings WHERE setting_key = ?`,
        [key],
        (err, row) => {
          if (err) {
            reject(err);
          } else {
            resolve(row ? row.setting_value : null);
          }
        }
      );
    });
  }

  async updateSetting(key, value) {
    return new Promise((resolve, reject) => {
      this.db.run(
        `INSERT OR REPLACE INTO system_settings (setting_key, setting_value, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)`,
        [key, value],
        function(err) {
          if (err) {
            reject(err);
          } else {
            resolve({ changes: this.changes });
          }
        }
      );
    });
  }

  // Wi-Fi metrics methods
  async saveMetrics(metrics) {
    return new Promise((resolve, reject) => {
      this.db.run(
        `INSERT INTO wifi_metrics (total_hotspots, active_hotspots, utilization, critical_districts) VALUES (?, ?, ?, ?)`,
        [metrics.totalHotspots, metrics.activeHotspots, metrics.utilization, metrics.criticalDistricts],
        function(err) {
          if (err) {
            reject(err);
          } else {
            resolve({ id: this.lastID });
          }
        }
      );
    });
  }

  async getMetricsHistory(limit = 100) {
    return new Promise((resolve, reject) => {
      this.db.all(
        `SELECT * FROM wifi_metrics ORDER BY timestamp DESC LIMIT ?`,
        [limit],
        (err, rows) => {
          if (err) {
            reject(err);
          } else {
            resolve(rows);
          }
        }
      );
    });
  }

  // Close database connection
  close() {
    if (this.db) {
      this.db.close((err) => {
        if (err) {
          console.error('Error closing database:', err);
        } else {
          console.log('Database connection closed');
        }
      });
    }
  }
}

module.exports = new Database();
