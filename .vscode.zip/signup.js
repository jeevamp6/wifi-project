async function signupUser() {
  const fullname = document.getElementById("fullname").value;
  const email = document.getElementById("email").value;
  const username = document.getElementById("username").value;
  const role = document.getElementById("role").value;
  const password = document.getElementById("password").value;
  const confirmPassword = document.getElementById("confirmPassword").value;
  const errorMsg = document.getElementById("errorMsg");
  const successMsg = document.getElementById("successMsg");

  // Clear previous messages
  errorMsg.innerText = "";
  successMsg.innerText = "";

  // Validation
  if (password.length < 8) {
    errorMsg.innerText = "Password must be at least 8 characters long";
    return false;
  }

  if (password !== confirmPassword) {
    errorMsg.innerText = "Passwords do not match";
    return false;
  }

  try {
    // Send registration request to backend
    const response = await fetch('/api/auth/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        fullname: fullname,
        email: email,
        username: username,
        role: role,
        password: password
      })
    });

    const data = await response.json();

    if (response.ok) {
      // Show success message
      successMsg.innerText = "Account created successfully! Redirecting to login...";
      successMsg.style.color = "#28a745";

      // Clear form
      document.getElementById("fullname").value = "";
      document.getElementById("email").value = "";
      document.getElementById("username").value = "";
      document.getElementById("role").value = "";
      document.getElementById("password").value = "";
      document.getElementById("confirmPassword").value = "";

      // Redirect to login after 2 seconds
      setTimeout(() => {
        window.location.href = "login.html";
      }, 2000);
    } else {
      errorMsg.innerText = data.error || "Registration failed";
    }
  } catch (error) {
    console.error('Registration error:', error);
    errorMsg.innerText = "Network error. Please try again.";
  }

  return false; // prevent form reload
}
