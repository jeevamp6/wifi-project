const express = require('express');
const WebSocket = require('ws');
const http = require('http');
const cors = require('cors');
const path = require('path');
const bcrypt = require('bcrypt');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Database setup
const DB_PATH = path.join(__dirname, 'wifi_monitoring.db');
const db = new sqlite3.Database(DB_PATH);

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Global data store for real-time updates
let wifiData = {
  totalHotspots: 12500,
  activeHotspots: 9800,
  utilization: 62,
  criticalDistricts: 118,
  districts: [],
  lastUpdated: new Date().toISOString()
};

// Initialize database
async function initDatabase() {
  return new Promise((resolve, reject) => {
    const queries = [
      `CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fullname TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        username TEXT UNIQUE NOT NULL,
        role TEXT NOT NULL DEFAULT 'user',
        password TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        is_active BOOLEAN DEFAULT 1,
        last_login DATETIME
      )`,
      
      `CREATE TABLE IF NOT EXISTS activity_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        username TEXT,
        action TEXT NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        ip_address TEXT,
        FOREIGN KEY (user_id) REFERENCES users (id)
      )`,
      
      `CREATE TABLE IF NOT EXISTS districts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        total_hotspots INTEGER DEFAULT 0,
        active_hotspots INTEGER DEFAULT 0,
        utilization INTEGER DEFAULT 0,
        status TEXT DEFAULT 'normal',
        last_ping DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      `CREATE TABLE IF NOT EXISTS system_settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        setting_key TEXT UNIQUE NOT NULL,
        setting_value TEXT,
        description TEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      `CREATE TABLE IF NOT EXISTS wifi_metrics (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        total_hotspots INTEGER,
        active_hotspots INTEGER,
        utilization INTEGER,
        critical_districts INTEGER,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
      )`
    ];

    let completed = 0;
    queries.forEach(query => {
      db.run(query, (err) => {
        if (err) {
          console.error('Error creating table:', err);
          reject(err);
        } else {
          completed++;
          if (completed === queries.length) {
            seedInitialData().then(resolve).catch(reject);
          }
        }
      });
    });
  });
}

// Seed initial data
async function seedInitialData() {
  return new Promise((resolve, reject) => {
    // Create default admin user
    const hashedPassword = bcrypt.hashSync('admin123', 10);
    
    db.run(
      `INSERT OR IGNORE INTO users (fullname, email, username, role, password) VALUES (?, ?, ?, ?, ?)`,
      ['System Administrator', 'admin@wifi-monitor.com', 'admin', 'admin', hashedPassword],
      (err) => {
        if (err) {
          reject(err);
        } else {
          initializeDistricts().then(resolve).catch(reject);
        }
      }
    );
  });
}

// Initialize districts
async function initializeDistricts() {
  return new Promise((resolve, reject) => {
    const districts = [
      'North District', 'South District', 'East District', 'West District', 'Central District',
      'Northeast District', 'Northwest District', 'Southeast District', 'Southwest District', 'Metro District'
    ];

    let completed = 0;
    districts.forEach((name, index) => {
      const totalHotspots = Math.floor(Math.random() * 2000) + 500;
      const activeHotspots = Math.floor(Math.random() * 1500) + 300;
      const utilization = Math.floor(Math.random() * 40) + 40;
      const status = Math.random() > 0.7 ? 'critical' : Math.random() > 0.4 ? 'warning' : 'normal';

      db.run(
        `INSERT OR REPLACE INTO districts (id, name, total_hotspots, active_hotspots, utilization, status) VALUES (?, ?, ?, ?, ?, ?)`,
        [index + 1, name, totalHotspots, activeHotspots, utilization, status],
        (err) => {
          if (err) {
            console.error('Error inserting district:', err);
          } else {
            completed++;
            if (completed === districts.length) {
              loadDistrictsFromDB().then(resolve).catch(reject);
            }
          }
        }
      );
    });
  });
}

// Load districts from database
async function loadDistrictsFromDB() {
  return new Promise((resolve, reject) => {
    db.all(`SELECT * FROM districts ORDER BY name`, [], (err, rows) => {
      if (err) {
        reject(err);
      } else {
        wifiData.districts = rows;
        updateMetricsFromDistricts();
        resolve();
      }
    });
  });
}

// Update metrics from districts
function updateMetricsFromDistricts() {
  const totalHotspots = wifiData.districts.reduce((sum, district) => sum + district.total_hotspots, 0);
  const activeHotspots = wifiData.districts.reduce((sum, district) => sum + district.active_hotspots, 0);
  const utilization = totalHotspots > 0 ? Math.round((activeHotspots / totalHotspots) * 100) : 0;
  const criticalDistricts = wifiData.districts.filter(d => d.status === 'critical').length;
  
  wifiData.totalHotspots = totalHotspots;
  wifiData.activeHotspots = activeHotspots;
  wifiData.utilization = utilization;
  wifiData.criticalDistricts = criticalDistricts;
  wifiData.lastUpdated = new Date().toISOString();
}

// Real-time data simulation
async function simulateRealTimeData() {
  try {
    // Update main metrics
    wifiData.totalHotspots += Math.floor(Math.random() * 20) - 10;
    wifiData.activeHotspots += Math.floor(Math.random() * 30) - 15;
    wifiData.utilization = Math.max(0, Math.min(100, wifiData.utilization + Math.floor(Math.random() * 6) - 3));
    
    // Update district data
    for (let district of wifiData.districts) {
      const newActiveHotspots = Math.max(0, Math.min(district.total_hotspots, 
        district.active_hotspots + Math.floor(Math.random() * 20) - 10));
      const newUtilization = Math.max(0, Math.min(100, 
        district.utilization + Math.floor(Math.random() * 8) - 4));
      
      // Randomly change status
      const rand = Math.random();
      let newStatus = district.status;
      if (rand < 0.05) {
        newStatus = district.status === 'critical' ? 'warning' : 'critical';
      } else if (rand < 0.1) {
        newStatus = district.status === 'normal' ? 'warning' : 'normal';
      }
      
      // Update in database
      await new Promise((resolve, reject) => {
        db.run(
          `UPDATE districts SET active_hotspots = ?, utilization = ?, status = ?, last_ping = CURRENT_TIMESTAMP WHERE id = ?`,
          [newActiveHotspots, newUtilization, newStatus, district.id],
          (err) => {
            if (err) reject(err);
            else resolve();
          }
        );
      });
      
      // Update in-memory data
      district.active_hotspots = newActiveHotspots;
      district.utilization = newUtilization;
      district.status = newStatus;
      district.last_ping = new Date().toISOString();
    }
    
    // Recalculate metrics
    updateMetricsFromDistricts();
    
    // Save metrics to database
    await new Promise((resolve, reject) => {
      db.run(
        `INSERT INTO wifi_metrics (total_hotspots, active_hotspots, utilization, critical_districts) VALUES (?, ?, ?, ?)`,
        [wifiData.totalHotspots, wifiData.activeHotspots, wifiData.utilization, wifiData.criticalDistricts],
        (err) => {
          if (err) reject(err);
          else resolve();
        }
      );
    });
    
    // Broadcast to all connected clients
    broadcastUpdate();
    
  } catch (error) {
    console.error('Error in real-time data simulation:', error);
  }
}

// WebSocket broadcast function
function broadcastUpdate() {
  const message = JSON.stringify({
    type: 'data_update',
    data: wifiData
  });

  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  });
}

// WebSocket connection handler
wss.on('connection', (ws) => {
  console.log('New WebSocket client connected');
  
  // Send current data immediately
  ws.send(JSON.stringify({
    type: 'initial_data',
    data: wifiData
  }));

  ws.on('close', () => {
    console.log('WebSocket client disconnected');
  });

  ws.on('error', (error) => {
    console.error('WebSocket error:', error);
  });
});

// Helper functions
async function logActivity(userId, username, action, ipAddress = null) {
  return new Promise((resolve, reject) => {
    db.run(
      `INSERT INTO activity_logs (user_id, username, action, ip_address) VALUES (?, ?, ?, ?)`,
      [userId, username, action, ipAddress],
      function(err) {
        if (err) reject(err);
        else resolve({ id: this.lastID });
      }
    );
  });
}

// Middleware to check authentication
function requireAuth(req, res, next) {
  if (req.session && req.session.userId) {
    next();
  } else {
    res.redirect('/login');
  }
}

// Middleware to check role
function requireRole(role) {
  return (req, res, next) => {
    if (req.session && req.session.userRole === role) {
      next();
    } else {
      res.status(403).send('Access denied');
    }
  };
}

// Routes

// Home/Login page
app.get('/', (req, res) => {
  res.render('login');
});

app.get('/login', (req, res) => {
  res.render('login');
});

app.get('/signup', (req, res) => {
  res.render('signup');
});

// Authentication routes
app.post('/auth/login', async (req, res) => {
  const { username, password, loginType = 'user' } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }
  
  try {
    const user = await new Promise((resolve, reject) => {
      db.get(
        `SELECT * FROM users WHERE username = ? AND is_active = 1`,
        [username],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });
    
    if (user && bcrypt.compareSync(password, user.password)) {
      // Update last login
      await new Promise((resolve, reject) => {
        db.run(
          `UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?`,
          [user.id],
          (err) => {
            if (err) reject(err);
            else resolve();
          }
        );
      });
      
      // Log activity
      await logActivity(user.id, user.username, 'User logged in');
      
      // Redirect based on role
      let redirectUrl = '/dashboard';
      if (user.role === 'admin') {
        redirectUrl = '/admin';
      } else if (user.role === 'viewer') {
        redirectUrl = '/viewer';
      }
      
      res.json({ 
        success: true, 
        redirect: redirectUrl,
        user: {
          id: user.id,
          fullname: user.fullname,
          username: user.username,
          role: user.role
        }
      });
    } else {
      res.status(401).json({ error: 'Invalid credentials' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Login failed' });
  }
});

app.post('/auth/register', async (req, res) => {
  const { fullname, email, username, role, password } = req.body;
  
  if (!fullname || !email || !username || !role || !password) {
    return res.status(400).json({ error: 'All fields are required' });
  }
  
  if (password.length < 8) {
    return res.status(400).json({ error: 'Password must be at least 8 characters long' });
  }
  
  if (!['user', 'admin', 'viewer'].includes(role)) {
    return res.status(400).json({ error: 'Invalid role' });
  }
  
  try {
    const hashedPassword = bcrypt.hashSync(password, 10);
    
    await new Promise((resolve, reject) => {
      db.run(
        `INSERT INTO users (fullname, email, username, role, password) VALUES (?, ?, ?, ?, ?)`,
        [fullname, email, username, role, hashedPassword],
        function(err) {
          if (err) {
            if (err.message.includes('UNIQUE constraint failed')) {
              reject(new Error('Username or email already exists'));
            } else {
              reject(err);
            }
          } else {
            resolve({ id: this.lastID });
          }
        }
      );
    });
    
    await logActivity(null, 'system', `Created new user: ${username} (${role})`);
    
    res.status(201).json({ message: 'User created successfully' });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.post('/auth/forgot-password', async (req, res) => {
  const { username } = req.body;
  
  if (!username) {
    return res.status(400).json({ error: 'Username is required' });
  }
  
  try {
    const user = await new Promise((resolve, reject) => {
      db.get(
        `SELECT * FROM users WHERE username = ?`,
        [username],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        }
      );
    });
    
    if (user) {
      // In a real application, you would send an email here
      // For demo purposes, we'll just return success
      res.json({ success: true, message: 'Password reset instructions sent' });
    } else {
      res.status(404).json({ error: 'Username not found' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Password reset failed' });
  }
});

// Dashboard routes
app.get('/dashboard', (req, res) => {
  res.render('dashboard', { wifiData, userRole: 'user' });
});

app.get('/admin', (req, res) => {
  res.render('admin', { wifiData, userRole: 'admin' });
});

app.get('/viewer', (req, res) => {
  res.render('viewer', { wifiData, userRole: 'viewer' });
});

// API routes
app.get('/api/wifi-data', (req, res) => {
  res.json(wifiData);
});

app.get('/api/users', async (req, res) => {
  try {
    const users = await new Promise((resolve, reject) => {
      db.all(
        `SELECT id, fullname, email, username, role, created_at, is_active, last_login FROM users ORDER BY created_at DESC`,
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
    res.json(users);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

app.get('/api/logs', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 100;
    const logs = await new Promise((resolve, reject) => {
      db.all(
        `SELECT * FROM activity_logs ORDER BY timestamp DESC LIMIT ?`,
        [limit],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        }
      );
    });
    res.json(logs);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch logs' });
  }
});

// Start server
async function startServer() {
  await initDatabase();
  
  // Start real-time data updates
  setInterval(simulateRealTimeData, 2000);
  
  const PORT = process.env.PORT || 3000;
  server.listen(PORT, () => {
    console.log(`Unified Wi-Fi Monitoring System running on port ${PORT}`);
    console.log(`Dashboard: http://localhost:${PORT}`);
    console.log(`Database: SQLite (${DB_PATH})`);
  });
}

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('Shutting down gracefully...');
  db.close();
  process.exit(0);
});

startServer().catch(console.error);
